#include "wifi_manager.h"

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include "../../app_config.h"

// =====================================================
// Ket noi Wi-Fi. Tra ve true neu vao duoc mang.
// =====================================================
bool wifiConnect(unsigned long timeoutMs) {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);

  // 🔴 Bat IPv6 TRUOC khi noi. Do thuc te tren hotspot dien thoai:
  //     DNS phan giai duoc, nhung TCP toi cong 443 im lang du 15 giay.
  //     Thu tu PC cung mang do: noi bang ten mien thi duoc, nhung ep sang
  //     IPv4 (104.21.67.134:443) thi hong.
  //   => Mang nay KHONG dinh tuyen IPv4 ra internet. Nha mang di dong o VN
  //      gio phan lon la IPv6-only; dien thoai tu dich duoc cho chinh no
  //      nhung khong dich cho may noi nho. PC chay duoc chi vi Windows tu
  //      uu tien IPv6.
  //
  // Bat len la du, khong phai sua gi them: hostByName() cua core tu tra AAAA
  // truoc khi giao dien co dia chi IPv6 toan cuc, va NetworkClientSecure van
  // truyen ten mien rieng cho SNI nen Cloudflare khong tu choi bat tay.
  WiFi.STA.enableIPv6(true);

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  Serial.print("Dang ket noi WiFi");

  const unsigned long startTime = millis();

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");

    if (millis() - startTime >= timeoutMs) {
      Serial.println();
      Serial.println("Khong ket noi duoc WiFi");
      Serial.println("Kiem tra SSID, mat khau va bang tan 2.4 GHz");
      return false;
    }
  }

  Serial.println();
  Serial.println("WiFi connected");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
  Serial.print("WiFi RSSI: ");
  Serial.print(WiFi.RSSI());
  Serial.println(" dBm");

  // Dia chi IPv6 toan cuc do router quang ba (SLAAC), mat them vai giay sau
  // khi lien ket len. Cho co roi moi bao — tren mang IPv6-only thi day moi
  // la dia chi duy nhat ra duoc internet, thieu no la hong ca chuoi.
  const unsigned long v6Start = millis();
  while (!WiFi.STA.hasGlobalIPv6() && millis() - v6Start < 6000) {
    delay(200);
  }

  if (WiFi.STA.hasGlobalIPv6()) {
    Serial.print("IPv6 toan cuc: ");
    Serial.println(WiFi.STA.globalIPv6());
  } else {
    Serial.println("IPv6 toan cuc: KHONG CO");
    Serial.println("  Neu mang nay khong dinh tuyen IPv4 ra internet thi se");
    Serial.println("  khong goi duoc server. Doi sang WiFi co IPv4.");
  }
  return true;
}

// =====================================================
// Kiem tra duong mang theo tung chang
// =====================================================
// Tach ba chang de biet hong o dau: WiFi -> DNS -> TCP/TLS.
void wifiSelfTest() {
  Serial.printf("WiFi   : %s\n",
                WiFi.status() == WL_CONNECTED ? "da noi" : "CHUA NOI");
  Serial.printf("SSID   : %s\n", WiFi.SSID().c_str());
  Serial.printf("IP     : %s\n", WiFi.localIP().toString().c_str());
  Serial.printf("Gateway: %s\n", WiFi.gatewayIP().toString().c_str());
  Serial.printf("DNS    : %s\n", WiFi.dnsIP().toString().c_str());
  Serial.printf("RSSI   : %d dBm\n", (int)WiFi.RSSI());

  if (WiFi.status() == WL_CONNECTED) {
    IPAddress ip;
    unsigned long t = millis();
    if (WiFi.hostByName(API_HOST, ip)) {
      Serial.printf("DNS %s -> %s (%lu ms)\n",
                    API_HOST, ip.toString().c_str(), millis() - t);

      WiFiClientSecure c2;
      c2.setInsecure();
      t = millis();
      if (c2.connect(API_HOST, API_PORT, 15000)) {
        Serial.printf("TCP/TLS 443 OK (%lu ms) — duong mang tot\n", millis() - t);
        c2.stop();
      } else {
        Serial.printf("TCP/TLS 443 HONG (%lu ms)\n", millis() - t);
        Serial.printf("Heap con %u byte (bat tay TLS can ~45 KB)\n",
                      (unsigned)ESP.getFreeHeap());
      }
    } else {
      Serial.printf("DNS HONG (%lu ms) — mang khong phan giai duoc ten mien\n",
                    millis() - t);
    }
  }
}
