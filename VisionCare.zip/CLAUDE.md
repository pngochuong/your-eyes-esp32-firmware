# VisionCare — Project Context

Thiết bị hỗ trợ người khiếm thị chạy trên ESP32-S3: **giữ nút → chụp ảnh + thu giọng nói → POST lên server → phát câu trả lời ra loa**. Kèm một web server phụ để xem hình trực tiếp và chỉnh cảm biến.

Firmware Arduino (sketch `.ino` + thư mục `src/`). Không phải project PlatformIO, không có CMake, không có test tự động — kiểm chứng bằng biên dịch trong Arduino IDE và các lệnh chẩn đoán qua Serial.

---

## 1. Luồng chạy chính

```
setup()                      VisionCare.ino
  cameraStart()              không có camera → dừng hẳn, không dựng web server
  webLedBegin()
  wifiConnect(30s)           mất Wi-Fi vẫn đi tiếp (nút/mic/loa phải sống)
  startCameraServer()        chỉ khi có IP
  startAudio()               gọi SAU web server, để camera+httpd chiếm RAM trước
loop()                       chỉ trông chừng Wi-Fi, cứ 10 s một lần

task "audio" (ghim core 1)   audio_service.cpp — nơi DUY NHẤT biết trình tự
  consolePoll()              lệnh chẩn đoán Serial
  giữ BTN  → photoCapture() → recordWhileHeld() → normalizeRecording()
  nhả BTN  → apiSendCapture() (multipart: image=JPEG, audio=WAV)
           → playPcmStream() qua PcmSource (PCM thô / WAV / MP3)

core 0                       Wi-Fi/TCP + esp_http_server (stream MJPEG)
```

Các khối con (`camera_capture`, `audio_recorder`, `audio_dsp`, `api_client`, `audio_player`) **không biết gì về nhau**. Muốn đổi trình tự → sửa `audio_service.cpp`, đừng sửa các khối.

---

## 2. Phần cứng đang dùng (BOM)

| # | Linh kiện | Vai trò | Nguồn | GPIO / kết nối | Trạng thái |
|---|---|---|---|---|---|
| 1 | **Kit ESP32-S3 WROOM N16R8 CAM** (GOOUUU, pinout = ESP32S3_EYE) | MCU trung tâm, Wi-Fi | 5 V qua USB-C, regulator ra 3.3 V | xem pin map bên dưới | ✅ trong firmware |
| 2 | **MAX98357A** I2S Class-D amp | Phát câu trả lời ra loa | VIN 5 V (khuyến nghị) | BCLK=41, LRC/WS=42, DIN=21; SD/MODE thả nổi | ✅ |
| 3 | **INMP441** I2S MEMS mic | Thu giọng nói | **3.3 V — tuyệt đối không 5 V** | BCLK=41, WS=42, SD=47; L/R→GND (khe TRÁI) | ✅ |
| 4 | **Loa mini 3 W 8 Ω** | Ngõ ra tiếng | từ SPK± của MAX98357A | không nối GPIO | ✅ |
| 5 | **Camera OV2640 góc rộng 120° + cáp FPC 75 mm** | Ảnh cho OCR + mô tả cảnh + stream web | qua đế camera trên board | đã nối sẵn PCB, khai báo ở `camera_pins.h` | ✅ |
| 6 | **MKE-M02 Button Module** | Nút giữ-để-nói | tín hiệu TTL 3.3/5 V | SIG=GPIO1, `INPUT_PULLUP`, active LOW | ✅ |
| 7 | Breadboard 400 point | Prototype | — | — | chưa test |
| 8 | Jumper wire | Đấu nối | — | — | chưa test |

Nguồn: [BangTomTat.csv](BangTomTat.csv) (bảng đầy đủ: dòng tiêu thụ, kích thước, độ tin cậy từng số liệu).

### Pin map (chốt trong [app_config.h](app_config.h))

| Chức năng | GPIO |
|---|---|
| I2S BCLK (chung mic + amp) | 41 |
| I2S WS/LRC (chung) | 42 |
| I2S DOUT → amp DIN | 21 |
| I2S DIN ← mic SD | 47 |
| Nút nhấn | 1 (active LOW) |
| Camera XCLK / SIOD / SIOC / PCLK / VSYNC / HREF | 15 / 4 / 5 / 13 / 6 / 7 |
| Camera D0–D7 | 11, 9, 8, 10, 12, 18, 17, 16 |
| Đèn chiếu sáng (FLASH_LED_PIN) | **-1 = chưa lắp** |

Chân **còn trống**: 2, 14, 38, 39, 40, 48 (38–40 là thẻ SD, 48 là NeoPixel onboard — chỉ dùng khi chấp nhận bỏ hai thứ đó). Tránh: GPIO0/3/45/46 (strap), 19/20 (USB-JTAG).

### Cài đặt Arduino IDE (bắt buộc)

Board `ESP32S3 Dev Module` · PSRAM `OPI PSRAM` · Partition Scheme `Huge APP (3MB No OTA/1MB SPIFFS)` · Flash Size `16MB` · arduino-esp32 core 3.3.x.
Không chọn đúng PSRAM OPI + Huge APP thì firmware (~1.23 MB) **không nạp nổi**.

Thư viện: `esp32-camera`, `driver/i2s_std.h` (ESP-IDF, không dùng `ESP_I2S`), `WiFi`/`WiFiClientSecure`, `esp_http_server`, `libhelix-mp3` (đã chép sẵn vào `src/libhelix-mp3/`).

### arduino-cli — đường dẫn và lệnh có sẵn trên máy này

| Mục | Giá trị |
|---|---|
| Thực thi | `C:\Program Files\Arduino CLI\arduino-cli.exe` — **đã có trong PATH**, gõ thẳng `arduino-cli` |
| Phiên bản | 1.5.1 |
| Thư mục data (core + tool) | `C:\Users\PCPV\AppData\Local\Arduino15` |
| Sketchbook (thư viện người dùng) | `C:\Users\PCPV\OneDrive - Trường ĐH CNTT - University of Information Technology\Documents\Arduino` |
| File config | không có (`config dump` trả `{}`) — đang chạy toàn bộ bằng giá trị mặc định |
| Core đã cài | `esp32:esp32` **3.3.10** (mới nhất 3.3.11), `arduino:avr` 1.8.8 |
| Thư viện cài riêng | không có — mọi thứ project dùng đều đi kèm core hoặc nằm trong `src/` |

**Biên dịch** (FQBN đã gộp sẵn ba tuỳ chọn bắt buộc ở bảng trên — thiếu một cái là không nạp nổi):

```powershell
arduino-cli compile -b "esp32:esp32:esp32s3:PSRAM=opi,PartitionScheme=huge_app,FlashSize=16M" "e:\VisionCare"
```

Đã chạy thật, sạch: **1228818 byte (39% của 3145728)**, RAM tĩnh 70268 byte (21%). Con số program storage này là mốc so sánh — lệch nhiều so với nó thì có gì đó vừa đổi.

**Nạp** — `board list` không nhận diện được board (chỉ hiện `Unknown` trên một loạt COM), nên phải tự xác định cổng bằng cách rút/cắm rồi so danh sách:

```powershell
arduino-cli board list
arduino-cli upload -p COM<x> -b "esp32:esp32:esp32s3:PSRAM=opi,PartitionScheme=huge_app,FlashSize=16M" "e:\VisionCare"
arduino-cli monitor -p COM<x> -c baudrate=115200
```

Tra tên tuỳ chọn khác của board: `arduino-cli board details -b esp32:esp32:esp32s3`.

---

## 3. Cấu trúc mã

**Gốc thư mục = những gì người dùng sửa. `src/` = mã.**

| File gốc | Nội dung |
|---|---|
| [VisionCare.ino](VisionCare.ino) | **SSID + mật khẩu Wi-Fi** (dòng 37–38), rồi `setup()` + `loop()` |
| [app_config.h](app_config.h) | endpoint API, timeout mạng, chân GPIO, XCLK, thông số thu âm |
| [board_config.h](board_config.h) | chọn model camera (`CAMERA_MODEL_ESP32S3_EYE`) |
| [camera_pins.h](camera_pins.h) | sơ đồ chân camera theo model |
| [HUONG_DAN_LAP_TUNG_BUOC.md](HUONG_DAN_LAP_TUNG_BUOC.md) | nhật ký bring-up 8 giai đoạn + số liệu đo thực tế |
| [BangTomTat.csv](BangTomTat.csv) | bảng linh kiện đầy đủ |

### `src/camera/`
| File | Việc |
|---|---|
| [camera_device](src/camera/camera_device.h) | dựng `camera_config_t`, `cameraStart()/cameraReinit()/cameraIsReady()`. **Nguồn duy nhất** của frame size + JPEG quality |
| [camera_tuning](src/camera/camera_tuning.h) | profile cảm biến cho OCR, `cameraWarmUp()`, in setting. Mọi lý do "vì sao đặt số này" nằm trong `.cpp` |
| [camera_capture](src/camera/camera_capture.h) | `photoCapture()` chụp một LOẠT rồi giữ khung nét nhất vào PSRAM; đèn chiếu sáng; `photoMeasureSharpness()` (~200 ms, chỉ dùng khi chẩn đoán) |

### `src/net/`
| File | Việc |
|---|---|
| [wifi_manager](src/net/wifi_manager.h) | `wifiConnect()`, `wifiSelfTest()` (Wi-Fi → DNS → TCP/TLS) |
| [http_body_reader](src/net/http_body_reader.h) | `BodyReader` đọc thân HTTP cả `Content-Length` lẫn `chunked` |
| [api_client](src/net/api_client.h) | `apiSendCapture()` — TLS, dựng multipart, đọc status + header. **Không phát gì ra loa**, trả `ApiReply` để người gọi tự đọc thân |

### `src/audio/`
| File | Việc |
|---|---|
| [audio_i2s](src/audio/audio_i2s.h) | mở kênh I2S full-duplex, `i2sSetSampleRate()`, `i2sWriteSilence()` |
| [audio_buffers](src/audio/audio_buffers.h) | `recBuf[]` (thu) + `stageBuf[]` (phát) — xin MỘT lần lúc khởi động, giữ đến khi tắt máy |
| [audio_recorder](src/audio/audio_recorder.h) | `recordWhileHeld()`, `measureNoiseOnly()` — chỉ đọc mic |
| [audio_dsp](src/audio/audio_dsp.h) | làm việc TẠI CHỖ trên `recBuf[]`: `quietestRms()`, `highBandRms()`, `noiseGate()`, `normalizeRecording()` |
| [audio_format](src/audio/audio_format.h) | `wavHeader()`, `parseAudioFormat()`, `readWavHeader()` — thuần số liệu, không đụng phần cứng |
| [pcm_source](src/audio/pcm_source.h) | `PcmSource`: PCM thô lấy thẳng từ socket, hoặc giải mã MP3 (Helix) trước |
| [audio_player](src/audio/audio_player.h) | `playPcmStream()` vừa nhận vừa phát, đệm tự điều chỉnh; `playTone()` để chẩn đoán |
| [audio_service](src/audio/audio_service.h) | **điều phối** — file duy nhất biết trình tự nút → ảnh → tiếng → server → loa |

### `src/web/`, `src/diag/`, `src/util/`
| File | Việc |
|---|---|
| [web_server](src/web/web_server.h) | cổng 80: `/`, `/capture`, `/status`, `/control`, `/bmp`, `/xclk`, `/reg`, `/greg`, `/pll`, `/resolution` · cổng 81: `/stream` (MJPEG) |
| [web_index_html.h](src/web/web_index_html.h) | trang HTML nhúng (949 dòng, gzip trong mảng byte) |
| [web_led](src/web/web_led.h) | LED onboard `LED_GPIO_NUM` chạy PWM, chỉnh qua `/control?var=led_intensity`. **Khác** đèn chiếu sáng của `camera_capture` |
| [serial_console](src/diag/serial_console.h) | phân phối lệnh `c/m/t/w/n` |
| [audio_diag](src/diag/audio_diag.h) | `diagSlotCompare()`, `diagSpeakerTone()`, `diagNoiseVsCamera()` |
| [camera_diag](src/diag/camera_diag.h) | `diagCaptureTest()` chụp thử + đo độ nét |
| [mem_alloc](src/util/mem_alloc.h) | `bigAlloc()` — **cửa duy nhất** cấp phát vài trăm KB, ưu tiên PSRAM rồi lui về RAM trong |
| `src/libhelix-mp3/` | bộ giải mã MP3 Helix chép từ ESP8266Audio (RCSL/RPSL). **Vendored — không sửa** |

---

## 4. Sửa gì thì vào đâu

| Muốn đổi | File |
|---|---|
| Wi-Fi SSID / mật khẩu | [VisionCare.ino:37](VisionCare.ino#L37) |
| Endpoint API, timeout mạng | [app_config.h:23-50](app_config.h#L23-L50) |
| Chân GPIO I2S / nút / đèn | [app_config.h:76-101](app_config.h#L76-L101) |
| Tần số thu, trần thời gian thu | [app_config.h:109-113](app_config.h#L109-L113) |
| XCLK camera | [app_config.h:74](app_config.h#L74) |
| Model camera | [board_config.h:16](board_config.h#L16) |
| Độ phân giải / chất lượng JPEG / profile cảm biến | `src/camera/camera_device.cpp` + `camera_tuning.cpp` |
| Ngưỡng lọc ồn, độ khuếch đại bản thu | `src/audio/audio_dsp.cpp` |
| Mức đệm khi phát, chống hụt | `src/audio/audio_player.cpp` |
| Trình tự một lần bấm nút | `src/audio/audio_service.cpp` |

**Quy ước:** `app_config.h` chỉ chứa thứ dùng chung nhiều khối. Các nút vặn riêng của một khối nằm ngay trong `.cpp` của khối đó, cạnh dòng mã dùng tới nó — đừng kéo lên `app_config.h`.

---

## 5. Ràng buộc đã trả giá để biết — đừng phá

- **Mọi file trong `src/` phải là `.cpp`, không `.ino`.** Arduino tự sinh prototype chèn lên đầu file gộp, trước `#include <WiFiClientSecure.h>` → `redeclared as different kind of entity`. Đổi lại: mỗi `.cpp` phải tự `#include <Arduino.h>`.
- **Arduino chỉ biên dịch đệ quy trong `src/`**, không vào thư mục con khác ở gốc. Module mới bắt buộc nằm trong `src/`.
- **I2S TX và RX dùng CHUNG một khối clock.** Không thể "tắt loa khi thu" bằng cách disable TX. `i2sSetSampleRate()` phải tắt cả hai chiều.
- **Server trả WAV 48 kHz, mic thu 16 kHz** → đổi sample rate hai lượt **mỗi lần bấm**, không phải trường hợp hiếm.
- **`BODY_GAP_MS = 30000`, không phải 8000.** Server sinh tiếng theo TỪNG CÂU; khoảng nghỉ giữa hai câu có thể vượt 8 s. Để nhỏ thì firmware tưởng hết luồng và **vứt mất phần còn lại của câu trả lời** — đã xảy ra đúng như vậy.
- **Server xử lý ~40 giây thật.** `NET_TIMEOUT_MS = 90000`; Cloudflare tự ngắt ở 100 s (lỗi 524). Người dùng nhả nút rồi phải đợi ~40 s — giới hạn của server, board không nhanh hơn được.
- **`XCLK = 16 MHz` chứ không 20 MHz** vì cáp FPC 75 mm (dài gấp 3 cáp gốc, 8 đường song song không bọc chống nhiễu). Nhanh quá → vệt sọc ngang, `EV-EOF-OVF`, hoặc `esp_camera_init()` trả 0x105.
- **Không gửi `Expect: 100-continue`.** Server không trả `100 Continue` → treo tới timeout. Board tự dựng header nên không dính; nhưng test bằng `curl` phải thêm `-H "Expect:"`.
- **Không có vòng lặp vô hạn trong task audio.** Từng có chế độ chỉnh nét ống kính chờ ký tự Serial — nó chặn luôn task audio, nút mất tác dụng, nhìn ngoài giống hệt thiết bị hỏng. Đã bỏ.
- **Buffer lớn xin một lần lúc khởi động**, không xin theo lần bấm nút — PSRAM phân mảnh sẽ làm cấp phát thất bại giữa chừng và người dùng chỉ thấy máy im lặng.
- **`startAudio()` gọi SAU `startCameraServer()`** để camera + httpd chiếm RAM trước; phần PSRAM còn lại mới là phần audio thật sự được dùng.
- **Ảnh mờ vì PHÒNG TỐI, không phải cấu hình sai.** Mọi thiết lập phần mềm chỉ dịch cân giữa nhoè-chuyển-động và nhiễu-hạt, không tạo thêm ánh sáng. Lối thoát duy nhất: lắp đèn vào `FLASH_LED_PIN`.
- `setInsecure()` đang được dùng cho TLS (không xác thực chứng chỉ) — đã biết, ghi trong hướng dẫn GĐ 6.

---

## 6. API contract

```
POST https://api.visioncare-host.uk/process        (443, TLS)
Content-Type: multipart/form-data
  field "image" — capture.jpg,  image/jpeg
  field "audio" — record.wav,   audio/wav (PCM 16-bit mono 16 kHz)

Trả về 200:
  audio/wav (đo được: PCM 16-bit mono 48 kHz, có Content-Length)
  hoặc audio/mpeg → giải mã bằng Helix
  hoặc PCM thô kèm header  x-audio-format: pcm_s16le;rate=16000;channels=1
```
Nhánh `chunked` vẫn giữ làm dự phòng — Cloudflare có thể đổi bất cứ lúc nào.

---

## 7. Lệnh chẩn đoán (gõ qua Serial, 115200)

| Phím | Việc |
|---|---|
| `c` | chụp thử + đo độ nét, không gửi đi đâu |
| `m` | nghe so sánh hai kiểu ghi khe I2S (đoán chế độ SD_MODE của amp) |
| `t` | phát sin sạch tăng dần biên độ, đo méo tiếng bằng chính mic |
| `w` | kiểm tra đường mạng theo chặng: Wi-Fi → DNS → TCP/TLS |
| `n` | đo nền nhiễu khi camera BẬT và khi camera TẮT |

---

## 8. Quy ước khi viết mã ở project này

- **Comment bằng tiếng Việt KHÔNG dấu** trong mã nguồn (`.ino`, `.h`, `.cpp`) — giữ nguyên phong cách hiện có. File `.md`/`.csv` thì có dấu bình thường.
- Comment giải thích **vì sao**, không phải **cái gì**. Dấu 🔴 đánh dấu chỗ đã sai một lần rồi và lý do không được sửa lại.
- Mỗi header mở đầu bằng một khối `===` nói rõ khối đó **lo gì và KHÔNG lo gì**. Thêm file mới thì giữ đúng khuôn đó.
- Một khối không gọi sang khối ngang hàng — mọi phối hợp đi qua `audio_service`.
